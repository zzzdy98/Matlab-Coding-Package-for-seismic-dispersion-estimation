clc;
clear all;

%% ------------------ 1: FEI_model ----------------------- %%

load('Input\Log_model.mat');
timeRan = 1:length(EI_true);

%% ------------------ 2: FEI_Inversion ------------------- %%
    angles = [1:10; 11:20; 21:30]; 
    theta  = angles*pi/180;
    frequency = [20 80];

for mm= 1:length(frequency)    
    for kk = 1:size(angles,1)
        
    EI0 = EI_model(kk,:,mm)';
        
    nt = length(EI0);    
    dt = 1e-3;
    t0 = 0.1;
    f0 = frequency(mm);
    [wav, time] = Ricker(f0, t0, nt, dt);
    wav = wav.';
    t0_i = floor(t0/dt);

    weight = ones(nt,length(theta));
    norm = 1;
    
    [data_angle_true] = fwmod(dt,t0,wav,EI_true(kk,:,mm),theta(kk,:));
    data_true = sum(data_angle_true,2)/length(angles);
    data_stack_true(:,kk,mm) = data_true;

    EIscale = 50;
    xi = zeros(1*nt,1); 

    mute = ones(size(EI0)); 
    mute(1:2) = 0;

    alpha_EI   = 0e-6; 

    save params_seis.mat data_true weight dt t0 wav EIscale EI0 theta alpha_EI mute norm;

    [xo, hist, iters]=wei_lbfgs_hess('avo_seis', xi, 10, 100, 3, 10, 1e-4, .9, 1e-6, 1e-12, 1e-16);

    Nl = length(EI0);
    EIf   = EI0+xo(1:Nl,end)*EIscale;
    
    [data_angle_inverted] = fwmod(dt,t0,wav,EIf,theta(kk,:));
    data_inverted = sum(data_angle_inverted,2)/length(angles);

    data_stack_inverted(:,kk,mm) = data_inverted;
    EI_inverted(:,kk,mm)     = EIf;

    rmse_seis = ((data_true-data_inverted)).^2; 
    rmse_seis = sqrt(rmse_seis); 
    data_rmse_seis(:,kk,mm) = rmse_seis;

    end
end

save('Input\FEI_inverted.mat');

%% Figure: LF
LineWidth   = 1.5;
FontSize    = 18;
gridalphasize  = 0.5;
SubplotNum = 7;

figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
plot(EI_true(1,:,1),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(1,:,1),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,1,1),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{LF}-5��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
ylabel('\itt \rm(ms)','fontsize',FontSize)
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([7 12]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;
                
h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.19 0.125 0.075 0.42])
plot(EI_true(2,:,1),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(2,:,1),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,2,1),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{LF}-15��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([7 12]);  
set(gca, 'yTick',0:50:220); 
bookfont(FontSize)
hold on; axis ij;

h3 = subplot(1,SubplotNum,3);
set(h3,'position',[0.31 0.125 0.075 0.42])
plot(EI_true(3,:,1),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(3,:,1),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,3,1),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{LF}-25��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([7 12]);  
set(gca, 'yTick',0:50:220);
legend1 = legend('\rmTrue','\rmInitial','\rmInverted','Fontsize',FontSize,'Location','NorthOutside');
set(legend1,...
    'Position',[0.1073717948718 0.440014285896044 0.0801282051282049 0.0896830748482805]);
bookfont(FontSize)
hold on; axis ij;

%%
figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
wigb(real(data_stack_true(:,:,1)),1,1:3,timeRan,0.04);hold on;
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)    
    
h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.19 0.125 0.075 0.42])
wigb(real(data_stack_inverted(:,:,1)),1,1:3,timeRan,0.04);hold on;
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)    

h3 = subplot(1,SubplotNum,3);
set(h3,'position',[0.31 0.125 0.075 0.42])
wigb(abs(data_rmse_seis(:,:,1)),1,1:3,timeRan,0.002);hold on; % RMSE 0.002
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)

%% Figure: HF
figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
plot(EI_true(1,:,2),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(1,:,2),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,1,2),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{HF}-5��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
ylabel('\itt \rm(ms)','fontsize',FontSize)
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([8 13]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;
                
h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.19 0.125 0.075 0.42])
plot(EI_true(2,:,2),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(2,:,2),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,2,2),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{HF}-15��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([8 13]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;

h3 = subplot(1,SubplotNum,3);
set(h3,'position',[0.31 0.125 0.075 0.42])
plot(EI_true(3,:,2),timeRan, '-k','linewidth',LineWidth); hold on
plot(EI_model(3,:,2),timeRan, '-b','linewidth',LineWidth); hold on
plot(EI_inverted(:,3,2),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\rmEI_{HF}-25��'];['\rm(km/s��g/cm^3)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([8 13]);  
set(gca, 'yTick',0:50:220);
legend1 = legend('\rmTrue','\rmInitial','\rmInverted','Fontsize',FontSize,'Location','NorthOutside');
set(legend1,...
    'Position',[0.1073717948718 0.440014285896044 0.0801282051282049 0.0896830748482805]);
bookfont(FontSize)
hold on; axis ij;

%%
figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
wigb(real(data_stack_true(:,:,2)),1,1:3,timeRan,0.02);hold on;
set(gca, 'XTick', [0.5 1.5 2.5]);
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)

h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.19 0.125 0.075 0.42])
wigb(real(data_stack_inverted(:,:,2)),1,1:3,timeRan,0.02);hold on;
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)

h3 = subplot(1,SubplotNum,3);
set(h3,'position',[0.31 0.125 0.075 0.42])
wigb(real(data_rmse_seis(:,:,2)),1,1:3,timeRan,0.002);hold on; % RMSE 0.002
set(gca, 'XTick', [1 2 3]);
set(gca,'XTickLabel',{'5' '15' '  25'},'fontsize',FontSize);
xlabel('\it�� \rm(��)','fontsize',FontSize) 
set(gca,'XAxisLocation','bottom'); 
set(gca,'YtickLabel','') 
set(gca,'YTick', 0:50:200);
ylim([0 220]);
xlim([-0.5 4.5]);  
bookfont(FontSize)
