function [synth] = fwmod(dt,t0,wav,EI,theta)

Nl = length(EI);
t0_i = floor(t0/dt);

%% Data error and grad
trc   = AVO_EI(EI,theta);
synth = conv2(wav, trc);
synth = synth(1+t0_i:Nl+t0_i,:);
