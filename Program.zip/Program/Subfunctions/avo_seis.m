function [f, g] = avo_asgrad_seis(x)
load params_seis.mat data_true weight dt t0 wav EIscale EI0 theta alpha_EI mute norm;
 
Nl = length(x);
EI   = EI0 + EIscale * x(1:Nl);

t0_i = floor(t0/dt);

%% Data error and grad
trc   = AVO_EI(EI,theta);
synth = conv2(wav, trc);
synth = synth(1+t0_i:Nl+t0_i,:);
synth = sum(synth,2)/length(theta);%%%%%%%%
J = 0.5*sum(sum((data_true - synth).^2));

res = data_true-synth;
res = conv2(wav, res);
% res = sum(res,2); %%%%%%%%
res = res(1+t0_i:Nl+t0_i,:);
g=zeros(Nl,1);

a = 1/2;

for i = 2:Nl-1
    dEI0   = EI(i)     - EI(i-1);
    dEI1   = EI(i+1)   - EI(i);

    EIm0   = (EI(i) + EI(i-1))/2;
    EIm1   = (EI(i+1) + EI(i))/2;

    % Kf gradient
    g(i) = sum(a.*(1/EIm1 + dEI1/(2*(EIm1^2))).*res(i,:),2);
    g(i) = g(i,:) + sum(a.*(-1/EIm0 + dEI0/(2*(EIm0^2))).*res(i-1,:),2);

end

g(1) = g(2);
g(Nl) = g(Nl-1);

%% Model error and grad
%display('Computing Regularization gradient');

fm = 0.5*alpha_EI*sum((EI - EI0).^2); 
g(1:Nl) = g(1:Nl) + alpha_EI*(EI - EI0);

%% Scaling and Muting
%display('Scaling and muting');
g(1:Nl)=g(1:Nl)*EIscale;

g(1:Nl)=g(1:Nl).*mute;

f = J + fm;

