function Rpp = AVO_EI(EI, theta)

Nt = length(EI);
Ntheta = length(theta);
Rpp = zeros(Nt,Ntheta);

a = 1/2;


for i = 1:Nt-1
    dEI = EI(i+1) - EI(i);
    EIm = (EI(i+1) + EI(i))/2;  

    Rpp(i,:) = a.*(dEI/EIm);        
end