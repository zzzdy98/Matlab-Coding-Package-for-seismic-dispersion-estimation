clc;
clear all;

%% ------------------ 1: Log_model ------------------------------ %%

load('Input\Log_model.mat');
load('Input\FEI_inverted.mat','EI_inverted');
timeRan = 1:length(EI_true);

%% ----------------- 2: Inversion ---------------------------------- %%
angles = [5 15 25];
theta  = angles*pi/180;
frequency = [20 80];

EIdata = EI_inverted;  % FEI
EIdata0 = EI_elastic;  

% Determined based on the average of  logging data
r = ones(length(EIdata),1)*1.8;
Ip_0 = 10.76;
K_0 = 28.16;
mu_0 = 12.51;
rho0 = 2.56;
               
d1 = zeros(length(angles),1);
G1 = zeros(length(angles),3);
K_elastic = zeros(length(EIdata),1);
mu_elastic = zeros(length(EIdata),1);
rho_elastic = zeros(length(EIdata),1);

d2 = zeros(length(angles),1);
G2 = zeros(length(angles),2);
K_f = zeros(length(EIdata),length(frequency));
mu_f = zeros(length(EIdata),length(frequency));     

for kk = 1:length(EIdata)
     
    for i = 1:1:length(angles)
       
        a = (1/4-1/(3*r(kk)^2))*(sec(theta(i)))^2;
        b = 1/r(kk)^2*(1/3*(sec(theta(i)))^2-2*sin(theta(i))^2);
        c = 1/2-sec(theta(i))^2/4;
        A = Ip_0;
        Z = log(EIdata0(kk,i)/A);           
        
        d1(i,:) = Z;
        G1(i,1) = a;
        G1(i,2) = b;
        G1(i,3) = c;
        
    end
    
    DF1 = 10^(-1);
    I1 = eye(3,3);
    m1 = inv(G1'*G1+DF1^2*I1)*G1'*d1;

    K_elastic(kk,:) = exp(m1(1,:))*K_0;
    mu_elastic(kk,:) = exp(m1(2,:))*mu_0;
    rho_elastic(kk,:) = exp(m1(3,:))*rho0;
       
    vp1 = sqrt((K_elastic(kk,:)+4/3*mu_elastic(kk,:))/rho_elastic(kk,:));
    vs1 = sqrt(mu_elastic(kk,:)/rho_elastic(kk,:));
    r1 = vp1/vs1;
    Ip1 = vp1*rho_elastic(kk,:);
    
    for f = 1:length(frequency)
        for i = 1:1:length(angles) 
            
            a = (1/4-1/(3*r1^2))*(sec(theta(i)))^2;
            b = 1/r1^2*(1/3*(sec(theta(i)))^2-2*sin(theta(i))^2);
            A1 = Ip1;

            Z_f = log(EIdata(kk,i,f)/A1);
            Z_f0 = log(EIdata0(kk,i)/A1);
            delta_Z = Z_f-Z_f0;
            d2(i,:) = delta_Z+a*m1(1,:)+b*m1(2,:);
            G2(i,1) = a;
            G2(i,2) = b;
        end
        
        DF2 = 10^(-0.5);
        I2 = eye(2,2);
        m2 = inv(G2'*G2+DF2^2*I2)*G2'*d2;

        K_f(kk,f)  = exp(m2(1,:))*K_elastic(kk,:);
        mu_f(kk,f) = exp(m2(2,:))*mu_elastic(kk,:);
    end   
    
end

result_K_elastic   = K_elastic;
result_mu_elastic  = mu_elastic;
result_rho_elastic = rho_elastic;
    
result_K_f  = K_f;
result_mu_f = mu_f;

%% ----------------- 3: Dispersion -------------------------------- %%
DK = (result_K_f(:,2)-result_K_f(:,1))./sqrt(result_K_f(:,1).*result_K_f(:,2))/2;
DMu = (result_mu_f(:,2)-result_mu_f(:,1))./sqrt(result_mu_f(:,1).*result_mu_f(:,2))/2;

for i = 1:length(EIdata)   
    if DK(i)<0
        DK(i) = 0;
    end
    
    if DMu(i)<0
        DMu(i) = 0;
    end  
end

%% Figure: elastic moduli
LineWidth   = 1.5;
FontSize    = 18;
gridalphasize  = 0.5;
SubplotNum = 7;

figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
plot(K_LF,timeRan, '-k','linewidth',LineWidth); hold on
plot(result_K_f(:,1),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\itK_{\rmLF}'];['\rm(GPa)']},'fontsize',FontSize)
ylabel('\itt \rm(ms)','fontsize',FontSize)
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([10 40]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;

h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.17 0.125 0.075 0.42])
plot(K_HF,timeRan, '-k','linewidth',LineWidth); hold on
plot(result_K_f(:,2),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\itK_{\rmHF}'];['\rm(GPa)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([10 40]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;


h3 = subplot(1,SubplotNum,3);
set(h3,'position',[0.27 0.125 0.075 0.42])
plot(mu_LF,timeRan, '-k','linewidth',LineWidth); hold on
plot(result_mu_f(:,1),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\it��_{\rmLF}'];['\rm(GPa)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([0 20]);  
set(gca, 'yTick',0:50:220);
bookfont(FontSize)
hold on; axis ij;

h4 = subplot(1,SubplotNum,4);
set(h4,'position',[0.37 0.125 0.075 0.42])
plot(mu_HF,timeRan, '-k','linewidth',LineWidth); hold on
plot(result_mu_f(:,2),timeRan, '-r','linewidth',LineWidth); hold on
xlabel({['\it��_{\rmHF}'];['\rm(GPa)']},'fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([0 20]);  
set(gca, 'yTick',0:50:220);
legend1 = legend('\rmTrue','\rmInverted','Fontsize',FontSize,'Location','NorthOutside');
set(legend1,...
    'Position',[0.103766025641031 0.468335256900764 0.0801282051282052 0.0613621038435604]);
bookfont(FontSize)
hold on; axis ij;

%% Figure: dispersion
figure('color',[1 1 1]);
h1 = subplot(1,SubplotNum,1);
set(h1,'position',[0.07 0.125 0.075 0.42])
plot(DK_LOG,timeRan, '-k','linewidth',LineWidth); hold on
plot(DK,timeRan, '-r','linewidth',LineWidth); hold on
xlabel('\itD_K','fontsize',FontSize)
ylabel('\itt \rm(ms)','fontsize',FontSize)
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([0 0.3]);  
set(gca, 'yTick',0:50:220);
set(gca, 'XTick',0:0.15:0.3);
bookfont(FontSize)
hold on; axis ij;

h2 = subplot(1,SubplotNum,2);
set(h2,'position',[0.17 0.125 0.075 0.42])
plot(DMu_LOG,timeRan, '-k','linewidth',LineWidth); hold on
plot(DMu,timeRan, '-r','linewidth',LineWidth); hold on
xlabel('\itD_��','fontsize',FontSize)
set(gca,'ytick',[],'yticklabel',[])
set(gca,'GridLineStyle','--','Gridalpha',gridalphasize) 
ylim([0 220]);
xlim([0 0.1]);  
set(gca, 'yTick',0:50:220);
legend1 = legend('\rmTrue','\rmInverted','Fontsize',FontSize,'Location','NorthOutside');
set(legend1,...
    'Position',[0.126602564102569 0.468335256900764 0.0801282051282051 0.0613621038435604]);
bookfont(FontSize)
hold on; axis ij;
